/* ============================================================
   SGICR · Celurepuestos — Base de datos MySQL
   ------------------------------------------------------------
   Base de datos : sgicr_celurepuestos
   Motor         : MySQL 8.0+ (InnoDB, utf8mb4)
   Contenido     : esquema completo + datos iniciales de la app
   Uso           : mysql -u root -p -P 2000 < base_datos_sgicr.sql
   ============================================================ */

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS sgicr_celurepuestos
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sgicr_celurepuestos;

-- ------------------------------------------------------------
-- 1. Configuración visual del sistema
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS configuracion (
  id              TINYINT UNSIGNED NOT NULL DEFAULT 1,
  color_principal VARCHAR(7)  NOT NULL DEFAULT '#7c3aed',
  color_menu      VARCHAR(7)  NOT NULL DEFAULT '#1b1030',
  fondo           LONGTEXT    NULL COMMENT 'Imagen de fondo en data URL (base64)',
  actualizado_en  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_cfg_unica CHECK (id = 1)
) ENGINE=InnoDB COMMENT='Colores y fondo personalizados';

-- ------------------------------------------------------------
-- 2. Usuarios del sistema
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(120) NOT NULL,
  correo        VARCHAR(190) NOT NULL,
  rol           ENUM('Administrador','Técnico','Recepcionista') NOT NULL DEFAULT 'Recepcionista',
  estado        ENUM('Activo','Inactivo') NOT NULL DEFAULT 'Activo',
  password_hash VARCHAR(255) NULL COMMENT 'SHA2-256 (demo) o bcrypt',
  ultimo_acceso DATE NULL,
  creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_correo (correo),
  KEY idx_usuarios_rol (rol, estado)
) ENGINE=InnoDB COMMENT='Cuentas de acceso y roles';

-- ------------------------------------------------------------
-- 3. Clientes
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clientes (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre     VARCHAR(150) NOT NULL,
  telefono   VARCHAR(30)  NULL,
  correo     VARCHAR(190) NULL,
  documento  VARCHAR(40)  NULL,
  creado_en  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_clientes_nombre (nombre),
  KEY idx_clientes_telefono (telefono)
) ENGINE=InnoDB COMMENT='Clientes registrados';

-- ------------------------------------------------------------
-- 4. Repuestos / inventario
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS repuestos (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre          VARCHAR(150) NOT NULL,
  categoria       ENUM('Pantallas','Baterías','Conectores','Cámaras','Estructuras','Otros')
                  NOT NULL DEFAULT 'Otros',
  cantidad        INT NOT NULL DEFAULT 0,
  precio_unitario DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  creado_en       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_repuestos_categoria (categoria),
  CONSTRAINT chk_repuestos_cantidad CHECK (cantidad >= 0),
  CONSTRAINT chk_repuestos_precio CHECK (precio_unitario >= 0)
) ENGINE=InnoDB COMMENT='Inventario de piezas y repuestos';

-- ------------------------------------------------------------
-- 5. Reparaciones (órdenes)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reparaciones (
  id                       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  orden                    INT UNSIGNED NOT NULL COMMENT 'Número visible: REP-0001',
  cliente_id               INT UNSIGNED NOT NULL,
  tecnico_id               INT UNSIGNED NULL,
  marca                    VARCHAR(50)  NOT NULL,
  modelo                   VARCHAR(100) NOT NULL,
  equipo                   VARCHAR(160) NOT NULL,
  imei                     VARCHAR(30)  NULL,
  color                    VARCHAR(40)  NULL,
  capacidad                ENUM('64 GB','128 GB','256 GB','512 GB') NULL,
  estado_fisico            ENUM('Bueno','Rayones','Pantalla rota','Golpeado','Mojado') NULL,
  accesorios               VARCHAR(255) NULL,
  motivo                   TEXT NULL,
  prioridad                ENUM('Baja','Media','Alta') NOT NULL DEFAULT 'Media',
  estado                   ENUM('Recibido','En diagnóstico','En reparación','Reparado','Entregado')
                           NOT NULL DEFAULT 'Recibido',
  fecha_ingreso            DATE NOT NULL,
  fecha_estimada_entrega   DATE NULL,
  diagnostico              TEXT NULL,
  costo_diagnostico        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  costo_mano_obra          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  costo_repuestos          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  costo_repuestos_estimado DECIMAL(12,2) NULL,
  cotizacion_estado        ENUM('Pendiente','Aprobada','Rechazada') NULL,
  foto_llegada             LONGTEXT NULL COMMENT 'Data URL base64',
  foto_entrega             LONGTEXT NULL COMMENT 'Data URL base64',
  fecha_entrega            DATE NULL,
  observaciones_entrega    TEXT NULL,
  metodo_pago              ENUM('Efectivo','Tarjeta','Transferencia','Nequi') NULL,
  valor_recibido           DECIMAL(12,2) NULL,
  garantia                 ENUM('Sin garantía','30 días','60 días','90 días') NULL,
  garantia_condiciones     TEXT NULL,
  creado_en                TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reparaciones_orden (orden),
  KEY idx_rep_estado (estado),
  KEY idx_rep_cliente (cliente_id),
  KEY idx_rep_tecnico (tecnico_id),
  KEY idx_rep_fecha (fecha_ingreso),
  CONSTRAINT fk_rep_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_rep_tecnico FOREIGN KEY (tecnico_id) REFERENCES usuarios (id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT chk_rep_costos CHECK (
    costo_diagnostico >= 0 AND costo_mano_obra >= 0 AND costo_repuestos >= 0
  )
) ENGINE=InnoDB COMMENT='Órdenes de reparación (flujo completo)';

-- ------------------------------------------------------------
-- 6. Repuestos usados en cada reparación
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reparacion_repuestos (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reparacion_id   INT UNSIGNED NOT NULL,
  repuesto_id     INT UNSIGNED NULL,
  nombre          VARCHAR(150) NOT NULL COMMENT 'Nombre al momento de usarlo',
  cantidad        INT NOT NULL,
  precio_unitario DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rr_reparacion_repuesto (reparacion_id, repuesto_id),
  KEY idx_rr_repuesto (repuesto_id),
  CONSTRAINT fk_rr_reparacion FOREIGN KEY (reparacion_id) REFERENCES reparaciones (id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_rr_repuesto FOREIGN KEY (repuesto_id) REFERENCES repuestos (id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT chk_rr_cantidad CHECK (cantidad > 0)
) ENGINE=InnoDB COMMENT='Piezas descontadas del inventario por orden';

-- ------------------------------------------------------------
-- 7. Comentarios del técnico
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reparacion_comentarios (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reparacion_id INT UNSIGNED NOT NULL,
  usuario_id    INT UNSIGNED NULL,
  texto         TEXT NOT NULL,
  fecha         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rc_reparacion (reparacion_id, fecha),
  CONSTRAINT fk_rc_reparacion FOREIGN KEY (reparacion_id) REFERENCES reparaciones (id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_rc_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Bitácora de trabajo de cada orden';

-- ------------------------------------------------------------
-- 8. Historial de cambios de estado
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reparacion_historial (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  reparacion_id   INT UNSIGNED NOT NULL,
  estado_anterior ENUM('Recibido','En diagnóstico','En reparación','Reparado','Entregado') NULL,
  estado_nuevo    ENUM('Recibido','En diagnóstico','En reparación','Reparado','Entregado') NOT NULL,
  usuario_id      INT UNSIGNED NULL,
  fecha           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rh_reparacion (reparacion_id, fecha),
  CONSTRAINT fk_rh_reparacion FOREIGN KEY (reparacion_id) REFERENCES reparaciones (id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_rh_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB COMMENT='Auditoría del flujo de estados';

-- ------------------------------------------------------------
-- 9. Trigger: registra automáticamente los cambios de estado
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_reparaciones_historial;
DELIMITER $$
CREATE TRIGGER trg_reparaciones_historial
AFTER UPDATE ON reparaciones
FOR EACH ROW
BEGIN
  IF NEW.estado <> OLD.estado THEN
    INSERT INTO reparacion_historial (reparacion_id, estado_anterior, estado_nuevo)
    VALUES (NEW.id, OLD.estado, NEW.estado);
  END IF;
END$$
DELIMITER ;

-- ------------------------------------------------------------
-- 10. Vistas de consulta rápida
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW vista_repuestos AS
SELECT
  id,
  nombre,
  categoria,
  cantidad,
  precio_unitario,
  (cantidad * precio_unitario) AS valor_inventario,
  CASE
    WHEN cantidad <= 0 THEN 'Agotado'
    WHEN cantidad <= 3 THEN 'Limitado'
    ELSE 'Disponible'
  END AS disponibilidad
FROM repuestos;

CREATE OR REPLACE VIEW vista_reparaciones AS
SELECT
  r.orden,
  r.equipo,
  c.nombre  AS cliente,
  c.telefono,
  u.nombre  AS tecnico,
  r.estado,
  r.fecha_ingreso,
  r.fecha_entrega,
  (r.costo_diagnostico + r.costo_mano_obra + r.costo_repuestos) AS total,
  r.cotizacion_estado,
  r.garantia
FROM reparaciones r
JOIN clientes c ON c.id = r.cliente_id
LEFT JOIN usuarios u ON u.id = r.tecnico_id;

CREATE OR REPLACE VIEW vista_clientes AS
SELECT
  c.id,
  c.nombre,
  c.telefono,
  c.correo,
  c.documento,
  COUNT(r.id)          AS equipos,
  MAX(r.fecha_ingreso) AS ultimo_ingreso
FROM clientes c
LEFT JOIN reparaciones r ON r.cliente_id = c.id
GROUP BY c.id, c.nombre, c.telefono, c.correo, c.documento;

-- ============================================================
-- DATOS INICIALES (los mismos que trae la página)
-- ============================================================

-- Configuración
INSERT INTO configuracion (id, color_principal, color_menu)
VALUES (1, '#7c3aed', '#1b1030')
ON DUPLICATE KEY UPDATE id = id;

-- Usuarios (contraseña demo: admin123, guardada como SHA2-256)
INSERT IGNORE INTO usuarios (id, nombre, correo, rol, estado, password_hash, ultimo_acceso) VALUES
(1, 'Adm. Técnico',  'admin@celurepuestos.com',    'Administrador', 'Activo', SHA2('admin123', 256), '2026-09-21'),
(2, 'Juan Pérez',    'jperez@celurepuestos.com',   'Técnico',       'Activo', SHA2('admin123', 256), '2026-09-21'),
(3, 'Luis Ramírez',  'lramirez@celurepuestos.com', 'Técnico',       'Activo', SHA2('admin123', 256), '2026-09-21'),
(4, 'María Díaz',    'mdiaz@celurepuestos.com',    'Técnico',       'Activo', SHA2('admin123', 256), '2026-09-21'),
(5, 'Sandra López',  'slopez@celurepuestos.com',   'Recepcionista', 'Activo', SHA2('admin123', 256), '2026-09-21');

-- Clientes
INSERT IGNORE INTO clientes (id, nombre, telefono, correo, documento) VALUES
(1, 'María González', '+57 310 4521 876', 'maria.g@gmail.com',      'CC 1.023.456.789'),
(2, 'Carlos Ríos',    '+57 300 7845 123', 'crios@hotmail.com',      NULL),
(3, 'Ana Torres',     '+57 315 2341 987', 'anatorres@gmail.com',    NULL),
(4, 'Pedro Silva',    '+57 321 9087 654', 'psilva@yahoo.com',       NULL),
(5, 'Laura Méndez',   '+57 312 5678 432', 'lmendez@gmail.com',      NULL),
(6, 'Jorge Castillo', '+57 318 4321 765', 'jcastillo@outlook.com',  NULL),
(7, 'Sandra Vargas',  '+57 305 8765 321', 'svargas@gmail.com',      NULL);

-- Repuestos
INSERT IGNORE INTO repuestos (id, nombre, categoria, cantidad, precio_unitario) VALUES
(1, 'Pantalla Samsung Galaxy A54', 'Pantallas',   5, 180000.00),
(2, 'Pantalla iPhone 14 Pro',      'Pantallas',   2, 320000.00),
(3, 'Batería Xiaomi Redmi 12',     'Baterías',    8,  65000.00),
(4, 'Conector de carga USB-C',     'Conectores', 15,  45000.00),
(5, 'Pantalla Motorola G84',       'Pantallas',   0, 120000.00),
(6, 'Cámara trasera Samsung A54',  'Cámaras',     3,  95000.00),
(7, 'Tapa trasera Huawei Nova 11', 'Estructuras', 1,  55000.00);

-- Reparaciones
INSERT IGNORE INTO reparaciones
  (orden, cliente_id, tecnico_id, marca, modelo, equipo, imei, estado,
   fecha_ingreso, diagnostico, costo_diagnostico, costo_mano_obra,
   costo_repuestos, costo_repuestos_estimado, motivo)
VALUES
(91, 1, 2, 'Samsung',  'Galaxy A54',   'Samsung Galaxy A54',   '357 821 093 274 501', 'En reparación',  '2026-09-20', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(90, 2, 3, 'Apple',    '14 Pro',       'iPhone 14 Pro',        '357 821 093 274 501', 'En diagnóstico', '2026-09-19', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(89, 3, 4, 'Xiaomi',   'Redmi 12',     'Xiaomi Redmi 12',      '357 821 093 274 501', 'Reparado',       '2026-09-18', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(88, 4, 2, 'Motorola', 'Moto G84',     'Motorola Moto G84',    '357 821 093 274 501', 'Entregado',      '2026-09-17', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(87, 5, 3, 'Huawei',   'Nova 11',      'Huawei Nova 11',       '357 821 093 274 501', 'Recibido',       '2026-09-17', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(86, 6, 4, 'Apple',    '13',           'iPhone 13',            '357 821 093 274 501', 'En reparación',  '2026-09-16', '', 30000.00, 80000.00, 180000.00, 180000.00, ''),
(85, 7, 2, 'Samsung',  'Galaxy S23',   'Samsung Galaxy S23',   '357 821 093 274 501', 'En diagnóstico', '2026-09-15', '', 30000.00, 80000.00, 180000.00, 180000.00, '');

-- ============================================================
-- USUARIO DE APLICACIÓN (opcional, recomendado)
-- ------------------------------------------------------------
-- Evita usar root desde la página. Cámbialo en producción.
-- ============================================================
CREATE USER IF NOT EXISTS 'sgicr_app'@'localhost' IDENTIFIED BY 'Sgicr_2026!App';
CREATE USER IF NOT EXISTS 'sgicr_app'@'127.0.0.1' IDENTIFIED BY 'Sgicr_2026!App';
GRANT SELECT, INSERT, UPDATE, DELETE ON sgicr_celurepuestos.* TO 'sgicr_app'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON sgicr_celurepuestos.* TO 'sgicr_app'@'127.0.0.1';
FLUSH PRIVILEGES;

-- ============================================================
-- FIN DEL SCRIPT
-- ============================================================
